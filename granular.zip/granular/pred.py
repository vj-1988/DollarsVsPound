# -*- coding: utf-8 -*-
"""
Created on Mon Apr 23 13:30:49 2018

@author: Vijay Anand
"""

import pandas as pd
import numpy as np
from flask import Flask,jsonify
from keras.models import load_model
from scaler import MinMaxScaler
import tensorflow as tf
import pickle
from sklearn.externals import joblib
from sklearn.ensemble import IsolationForest
from sklearn.externals import *
from collections import Counter
#==============================================================================
# Globals
#==============================================================================

app = Flask(__name__)
model=load_model('model.h5')
model._make_predict_function()
graph = tf.get_default_graph()
adModel = pickle.load(open('ad-P2.pkl', 'rb'))
#adModel=joblib.load('ad-P2.pkl')

scaler = MinMaxScaler()

#==============================================================================
# 
#==============================================================================

@app.route('/forecast')
def root():
    
    df=pd.read_csv('input.csv')
    
    feats=df.values[:,1:]
    
    scaler.fit(feats)
    feats=scaler.transform(feats)
    
    feats=feats.reshape(feats.shape[0],1,feats.shape[1])

    ## forecast

    with graph.as_default():
        forecast = model.predict(feats,batch_size=1)    
    
    forecast=scaler.inverse_transform(forecast)

    forecastJson={x:forecast[:,x].tolist() for x in range(1,forecast.shape[1])}
    
    ## AD
    
  
    print forecast.shape
    
    for x in range(forecast.shape[1]):
        
        anomalies=adModel.predict(forecast[:,x].reshape(-1,1)).tolist()
        print Counter(anomalies)
    
    
    return jsonify(forecastJson)
    
    
if __name__ == '__main__':
    app.run()
