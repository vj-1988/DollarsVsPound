# -*- coding: utf-8 -*-
"""
Created on Sat Feb 10 15:22:32 2018

@author: Vijay Anand
"""

import numpy as np

class MinMaxScaler:
    
    def __init__(self):
        
        self.minimum=None
        self.maximum=None
        
        self.lower=-1
        self.upper=1
        
    def fit(self,array):
        
        self.minimum=np.amin(array)
        self.maximum=np.amax(array)
        
    def transform(self,array,lower=-1,upper=1):
        
        self.lower=lower
        self.upper=upper
        
        if self.minimum == None or self.maximum == None:
            
            print ('Please fit the scaler beform transforming the array! Returning the array without scaling!')
            
            return array
            
            
        transformed_array=(((upper-lower)*((array-self.minimum)/(self.maximum-self.minimum)))+lower)
        
        return transformed_array
        
    def inverse_transform(self,array,lower=-1,upper=1):
        
        
        if self.minimum == None or self.maximum == None:
            
            print ('Please fit the scaler beform transforming the array! Returning the array without scaling!')
            
            return array
            
            
        inv_array=(((array-self.lower)*((self.maximum-self.minimum)/(upper-lower)))+self.minimum)
        
        return inv_array
        
        
            