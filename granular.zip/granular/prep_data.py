# -*- coding: utf-8 -*-
"""
Created on Mon Apr 23 15:59:08 2018

@author: vijay
"""

import pandas as pd
import os
import numpy as np

#==============================================================================
# TS to ip
#==============================================================================

def genDf(feats,ipLen):
    
    featCnt=len(feats)
    
    tmp=[]
    
    for ind,x in enumerate(feats):
        
        if featCnt-ind > ipLen:
            
            tmp.append(list(feats[ind:ind+120]))
            
    procFeats=np.array(tmp)    
    
    return procFeats 
    
    


#==============================================================================
# main
#==============================================================================

def main():
    
    col='db_database_resource_usage_opencursors'
    df=pd.read_csv('actual.csv')
    
    print (df.shape)
        
    ipFeats=df['db_database_resource_usage_opencursors'].tolist()
    ts=df[df.columns[0]]
    
    print (ts)
    
    ip=genDf(ipFeats,120)
    ts=ts.iloc[:ip.shape[0]]
    
    
    newDf=pd.DataFrame(columns=['Timestamp']+['Timestamp - '+str(x) for x in range(119,-1,-1)])
    
    newDf['Timestamp']=ts
    
    newDf.iloc[:,1:]=ip
    
    newDf.to_csv('input.csv',index=False)
    
if __name__=='__main__':
    main()